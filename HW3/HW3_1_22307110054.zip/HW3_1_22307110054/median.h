#ifndef MEDIAN_H
#define MEDIAN_H
#include<vector>
double median(std::vector<double>hw);
#endif
