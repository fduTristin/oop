#ifndef GUARD_grade_h
#define GUARD_grade_h

// 'grade.h'
#include <vector>

double grade(double, double, double);
double grade(double, double, const std::vector<double>&);


#endif

