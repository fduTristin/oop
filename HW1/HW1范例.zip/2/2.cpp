#include <iostream>
#include <string>

using std::cin;     using std::endl;
using std::cout;    using std::string;

int main() {
    int a, b, c, d;

    cout << "Enter the sid length of a square: ";
    cin >> a;
    for (int i = 0; i != a; ++i) {
        for (int j = 0; j != a; ++j) {
            cout << "* ";
        }
        cout << endl;
    }

    cout << "Enter the length and width of a rectangle: ";
    cin >> b >> c;
    for (int i = 0; i != c; ++i) {
        for (int j = 0; j != b; ++j) {
            cout << "* ";
        }
        cout << endl;
    }

    cout << "Enter the base length of an isosceles triangle(odd number): ";
    cin >> d;
    for (int i = 0; i != d / 2 + 1; ++i) {
        for (int j = 0; j != d; ++j) {
            if (j < d / 2 - i || j > d / 2 + i) {
                cout << "  ";
            } else {
                cout << "* ";
            }
        }
        cout << endl;
    }
    return 0;
}