#include <iostream>
#include <string>

using std::cin;     using std::endl;
using std::cout;    using std::string;

int main() {
    int year, month, day;
    cout << "Enter the baby's birthday: ";
    cin >> year >> month >> day;
    int day_of_month[13] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    for (int i = 1; i < 100; ++i) {
        if (year % 4 == 0 && year % 100 || year % 400 == 0) {
            day_of_month[2] = 29;
        } else {
            day_of_month[2] = 28;
        }
        if (day < day_of_month[month]) {
            ++day;
        } else {
            day = 1;
            if (month < 12) {
                ++month;
            } else {
                month = 1;
                ++year;
            }
        }
    }
    cout << "The baby's 100-day date is: " << year << ' ' << month << ' ' << day;
    return 0;
}